<?xml version="1.0" encoding="utf-8"?>
<jnlp 
    spec="1.0+" 
    codebase="https://smolka.lima-city.de/smonitor/trunk/ms"
    href="smonitor.jnlp.php">
  <information>
    <title>SMonitor</title>
    <vendor>powered by ABAP Developer</vendor>
    <homepage href="https://smolka.lima-city.de/index.php" />
    <description>SMonitor :: monitor server/systems/...</description>
    <icon kind="default" href="smonitor.png" />
    <icon kind="splash" href="splash.gif" />
    <offline-allowed />
    <shortcut online="false" install="true">
      <desktop />
      <menu submenu="SMonitor" />
    </shortcut>
  </information>
  <security>
    <all-permissions />
  </security>
  <resources>
    <java version="1.8+" /> 
    <jar href="smonitor.jar.php" main="true" />
  </resources>
  <update check="background" />
  <application-desc main-class="it.jes.monitor.SMonitor" />
</jnlp>
