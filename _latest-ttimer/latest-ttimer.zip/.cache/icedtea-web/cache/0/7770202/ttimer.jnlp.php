<?xml version="1.0" encoding="utf-8"?>
<jnlp 
    spec="1.0+" 
    codebase="https://smolka.lima-city.de/ttimer/trunk/ms"
    href="ttimer.jnlp.php">
  <information>
    <title>a Tea Timer 4 U</title>
    <vendor>powered by ABAP Developer</vendor>
    <homepage href="https://smolka.lima-city.de/index.php" />
    <description>Timer :: a-tea-timer-4-u</description>
    <icon kind="default" href="Tea-Timer.gif" />
    <icon kind="splash" href="splash.gif" />
    <offline-allowed />
    <shortcut online="false" install="true">
      <desktop />
      <menu submenu="a-Tea-Timer-4-U" />
    </shortcut>
  </information>
  <security>
    <all-permissions />
  </security>
  <resources>
    <java version="1.6+" /> 
    <jar href="ttimer.jar.php" main="true" />
  </resources>
  <update check="background" />
  <application-desc main-class="it.jes.timer.aTeaTimer4U" />
</jnlp>
